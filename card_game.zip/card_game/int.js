{
	data = [{
		"goalValue": [
			["8-9",8,5,3],
			["5-10",8,5,3]
		],
		"progress": [
			[1,0,0,0],
			[1,0,2,0]
		],
		"goalOpen": [
			[true, true, true, true],
			[true, true, true, true]
		],
		"numberOfCards": 3,
		"probabilityOfProgress": [1, 0.5],
		"showOpponentProgress": true,
		"opponent": "mirrorOpponent"
	},
	{
		"goalValue": [
			["8-9",8,5,3],
			["5-10",8,5,3]
		],
		"progress": [
			[1,0,0,0],
			[1,0,2,0]
		],
		"goalOpen": [
			[true, true, true, true],
			[true, true, true, true]
		],
		"numberOfCards": 3,
		"probabilityOfProgress": [1, 0.5],
		"showOpponentProgress": true,
		"opponent": "mirrorOpponent"
	}]
}