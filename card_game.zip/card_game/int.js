{
	data = {
		"goalValue": [
			[10,8,5,3],
			[10,8,5,3]
		],
		"progress": [
			[0,0,0,0],
			[0,0,0,0]
		],
		"goalOpen": [
			[true, true, true, true],
			[true, true, true, true]
		],
		"numberOfCards": 3,
		"probabilityOfProgress": [1, 1],
		"showOpponentProgress": false,
		"opponent": false,
	}
}