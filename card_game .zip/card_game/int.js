{
	data = {
		"goalValue": [
			[10,8,5,3],
			[10,8,5,3]
		],
		"progress": [
			[1,0,1,0],
			[0,1,0,1]
		],
		"goalOpen": [
			[true, true, true, true],
			[true, true, true, true]
		],
		"numberOfCards": 5,
		"probabilityOfProgress": [1, 1],
		"showOpponentProgress": false,
		"opponent": false,
	}
}