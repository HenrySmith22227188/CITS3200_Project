# CITS3200_Project
http://teaching.csse.uwa.edu.au/units/CITS3200/project/offered/Projects_2019/Farrell_multiple_goal_pursuit.html

To launch (for development/testing):
- Make sure all three files are in the same directory after you download them.
- Open the HTML file with the web browser of your choice.
- The JS and CSS files are automatically linked to the HTML file. 
- To interact with the CSS on Google Chrome, right click any element and select 'inspect element'. 
- From this menu, select the 'console' to interact with the JS. 
